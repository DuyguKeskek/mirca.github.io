#! /usr/bin/python
# Wrapper script to run fitMovie on the command line 
# see storm lib for details
# run as "fitMovie.py movieName psfFile thresh datamin nIter"
import sys,os

##define a null output
#fnull = open(os.devnull, 'w')
#sys.stdout = fnull
#sys.stderr= fnull

from daostorm import *

movieName   = sys.argv[1]
psfFile	    = sys.argv[2]
sigma	    = float(sys.argv[3])
thresh	    = float(sys.argv[4])
nIter	    = 4
sharphi = 100
fwhmpsf = 3.3
movieName = movieName[:-5]
psfFile = psfFile[:-5]

fitMovie(movieName,psfFile,sigmaBG=sigma,thresh=thresh,nIter=nIter,fwhmpsf=fwhmpsf,sharphi=sharphi)

#sys.stdout=sys.__stdout__
#sys.stderr=sys.__stderr__
#sys.stdout.write(psfImageName)
#sys.stdout.write('\n')

#close the null output
#fnull.close()

