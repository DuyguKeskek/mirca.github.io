README file for DAOSTORM v1.0
Seamus J Holden, 29-10-2010
Copyright (c) 2010, The Chancellor, Masters and Scholars of the University of Oxford.
All rights reserved.

A detailed installation guide may be found in 'INSTALL.txt'.
The manual is 'daostorm_users_manual.pdf'.
The DAOSTORM software is a python module 'daostorm.py'.
Test code and data is supplied: 'testdaostorm.py' and 'stormData1.519.fits'. See 'INSTALL.txt' for details.

The DAOSTORM software is released under the terms of the BSD license, see 'LICENSE.txt' for details.

If you use this software in work leading to scientific publication, please cite:
"Holden, S. J.; Uphoff, S. & Kapanidis, A. N. DAOSTORM: a general method for super-resolution imaging of very dense samples. Submitted, 2010"
