function tileFits(fileName,nTileX);
%function tileFits(fileName,nTileX);

nTileY=nTileX;
im=fits_read_image(fileName);
d = size(im);
tileIm = zeros(d(1)*nTileX,d(2)*nTileX);

mm = 1;
for ii = 1:d(1):nTileX*d(1)
  for jj = 1:d(2):nTileX*d(2)
    row = [ii : (ii + d(1) - 1)];
    col = [jj : (jj + d(2) - 1)];
    tileIm(row,col) = im(1:d(1),1:d(2),mm);
    mm = mm + 1;
  end
end

fits_write_image([fileName(1:end-4),'tile',num2str(nTileX^2),'.fits'],tileIm);
