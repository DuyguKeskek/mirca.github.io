function offsetFits(fileName,fileNameOut,offset)
% offsetFits(fileName,fileNameOut,offset)
image = fits_read_image(fileName);%read the data
image = image +offset;
fits_write_image(fileNameOut, image);%write the data

