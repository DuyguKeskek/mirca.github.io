function EndPixel = getEndPixel(TirfIm)
%  	EndPixel = getEndPixel(TirfIm)
% get EndPixel from TirfIm object

EndPixel = TirfIm.EndPixel;

