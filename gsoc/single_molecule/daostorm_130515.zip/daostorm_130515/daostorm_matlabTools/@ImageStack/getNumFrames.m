function NumFrames = getNumFrames(ImStack)
%  	NumFrames = getNumFrames(ImStack)
% get NumFrames from ImStack object

NumFrames = ImStack.NumFrames;

