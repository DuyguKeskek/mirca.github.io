function Stack = getStack(ImageStack)
%  	Stack = getStack(ImageStack)
% get Stack from ImageStack object

Stack = ImageStack.Stack;

