function CurrentFrame = getCurrentFrame(ImStack)
%  	CurrentFrame = getCurrentFrame(ImStack)
% get CurrentFrame from ImStack object

CurrentFrame = ImStack.CurrentFrame;

