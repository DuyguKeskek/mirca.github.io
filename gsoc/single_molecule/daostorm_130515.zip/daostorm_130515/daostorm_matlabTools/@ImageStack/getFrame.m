function Frame = getFrame(ImStack, n)
% 	function Frame = getFrame(ImStack, n)
% retrieve specified frame from ImStack
% 110808 SH modified to check if not uint16
%
% global GETFRAMECOUNT
%
% GETFRAMECOUNT = GETFRAMECOUNT + 1;
% fprintf('%d\n', GETFRAMECOUNT);
%


if n > ImStack.NumFrames
	error('Attempted to access out of bounds frame');
end

if ImStack.NumFrames == 1 %ie if there is only one frame
	startVector = double([ImStack.StartPixel, 1             ]);
	endVector =   double([ImStack.EndPixel  , ImStack.NAXIS2]);
else
	startVector = double([ImStack.StartPixel, 1             , n]);
	endVector =   double([ImStack.EndPixel  , ImStack.NAXIS2, n]);
end

% the axis definitions in matlab for fits files are 
% 90 degrees to the normal definition
% so rotate it
Frame = rot90(fits_read_image_subset(ImStack.ImPath, startVector, endVector));
clear fun fits_read_image_subset;

ImStack.CurrentFrame = n;

assignin('caller', inputname(1), ImStack);


