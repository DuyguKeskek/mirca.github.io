function StartPixel = getStartPixel(TirfIm)
%  	StartPixel = getStartPixel(TirfIm)
% get StartPixel from TirfIm object

StartPixel = TirfIm.StartPixel;

