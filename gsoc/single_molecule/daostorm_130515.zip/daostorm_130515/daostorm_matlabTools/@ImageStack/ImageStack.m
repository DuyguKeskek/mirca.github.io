function ImStack = ImageStack(impath, startpixel, endpixel, numFramesAvg)
% ImageStack class constructor
% 
%	ImStack = ImageStack(impath, startpixel) 
% 
% Description: 
%	Creates an object allowing access to the channels
% of a given tirfim frame and to an averaged image over all frames
%
% Inputs:
%	impath
%	startpixel (horizontal startpixel)
%	endpixel   (horizontal endpixel)
%	
% Data:	
%	ImPath
%	StartPixel
%	EndPixel
%	NumFrames
%	Average
%	CurrentFrame
%	
%
% Public Methods:
%	- get[all]
%	- setAverage( Imstack, AvgImage)
%	- getFrame( ImStack, n)
% Private Methods:
%
% History:
% 	130208 	- First alpha complete (SH)
%	180208 	- Function headers and help standardised (SH)
%	200208  - Completely revised to make it more memory efficient
%	210708  - Takes the numFramesAvg as an opt. argument to only average the first n frames
%
% Author:
%	Seamus Holden
%
% Notes:
%	AK group internal use only
%

ImageInfo = fits_read_header(impath);



%check whether there is more than one frame
if isfield(ImageInfo,'NAXIS3')
	ImStack.NumFrames= ImageInfo.NAXIS3;
else
	ImStack.NumFrames= 1;
end

ImStack.StartPixel = startpixel;

% if endpixel is inf, this flags we want the end of the image
if isinf(endpixel)
	ImStack.EndPixel = ImageInfo.NAXIS1;
else 
	ImStack.EndPixel = endpixel;
end

%these are the widths and the heights need them to read fits frames
ImStack.NAXIS1 = ImageInfo.NAXIS1;
ImStack.NAXIS2 = ImageInfo.NAXIS2;

ImStack.ImPath = impath;
ImStack.CurrentFrame = 1;

% Setup the class
ImStack = class(ImStack, 'ImageStack');

