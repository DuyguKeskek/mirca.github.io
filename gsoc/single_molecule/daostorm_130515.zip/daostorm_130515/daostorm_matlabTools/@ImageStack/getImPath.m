function ImPath = getImPath(ImStack)
%  	ImPath = getImPath(ImStack)
% get ImPath from ImStack object

ImPath = ImStack.ImPath;

