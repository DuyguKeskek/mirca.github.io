function stormHist =  plotDAOPHOTdata3(filename,lim,nSubPix)
%function stormHist =  plotDAOPHOTdata3(filename,lim,nSubPix)
% Plot a 2D histogram of the storm data, 
%   lim is the no of x,y pixels in the original image 
%   nSubPix is the number of super-resolved sub-pixels per original image pixel
%

xSize = lim(1);
ySize = lim(2);
xLims = [1:1/nSubPix:xSize];
yLims = [1:1/nSubPix:ySize];
data = importdata(filename);
if isstruct(data)%strip the header information
  data = data.data;
end
xyData = data(:,2:3);

stormHist = cast(hist3([xyData],{xLims, yLims}),'uint16');
stormHist = rot90(stormHist,1);
imwrite(stormHist,[filename,'.hist',num2str(nSubPix),'.tif'],'tif','Compression','none');

