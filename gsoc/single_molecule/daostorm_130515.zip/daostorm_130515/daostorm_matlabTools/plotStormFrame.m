function  plotStormFrame(imfile,frame,saturation)
% NB frame is zero indexed

if ~exist('frame','var')
  frame = 0;
end
if ~exist('saturation','var')
  saturation = 0.0;
end

xCol = 2;
yCol = 3;

crowdedResultFile = [imfile(1:end-5), '.pos.out'];
%load the image
imstack=ImageStack(imfile, 1, inf);

%normalise and saturate the image
im = double(getFrame(imstack,frame+1));
minFrame = min(im(:));
maxFrame = max(im(:));
%normalize
im = (im - minFrame)./(maxFrame - minFrame);
%saturate only high values
lim = stretchlim(im,[saturation/2,1-saturation/2]);
im = imadjust(im,lim,[]);

imWidth = size(im,1);
%im = rot90(im,3);
im = (im - min(im(:))) ./(max(im(:))-min(im(:)));

crowded = importdata(crowdedResultFile);
if ~isstruct(crowded)
  ctmp = crowded;
  clear crowded;
  crowded.data =ctmp;
end

crowded.data = crowded.data(find(crowded.data(:,1)==frame),:);

hold off;
imshow(im);
hold on;
[ySize,xSize] = size(im);
plot(crowded.data(:,xCol),(ySize +1) - crowded.data(:,yCol),'rx','MarkerSize',10,'LineWidth',2);

